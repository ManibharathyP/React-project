import React from 'react';
var system = require('./data.json');


export class Cisco_1 extends React.Component {
  constructor(props) {
    super(props);
    {
      this.state = { showing: true };

    }
  }
  changeButtonStatus(event) {
    var elem = event.target.parentElement.childNodes[1].firstChild;
    elem.classList.toggle("toggleDisplay");
  }
  render() {

    return (<div className="container-fluid box ">


      {
        system.map((val, i) => {
          return <div value={i} >
            <table className="table">
              <tr key={i}>
                <td><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val.operating}</td>
                <td><span className="version">Version :</span>&nbsp;{val.version}</td>
                <td>
                  <div className="mani">
                    <button className="assign" value={i} key={i} onClick={this.changeButtonStatus.bind(this)}>{val.assign}</button>
                    <div className="col-md-12">
                      <div className="hidden drop">
                        <button className="btn btn-default">All</button>
                        <button className="btn btn-default">Core</button>
                        <button className="btn btn-default">Distribution</button>
                        <button className="btn btn-default">Border Router</button>
                        <button className="btn btn-default">Access</button>
                        <button className="btn btn-default">Unknown</button>
                      </div>
                    </div>
                  </div>
                </td>
                <td>
                  <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
                </td>
              </tr>
            </table>
          </div>
        })
      }


    </div>);
  }
}

