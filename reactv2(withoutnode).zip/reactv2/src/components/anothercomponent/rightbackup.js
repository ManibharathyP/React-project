import React from 'react';
var system = require('./data.json');

export class Cisco_1 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box ">
      <div className="row">
        <div className="col-md-4">
          <ul>
            {
              system[1].operating.map((val, i) => {
                return <li className="fontcolor" key={i}><i className="fa fa-star star" aria-hidden="true"></i>&nbsp;{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-4">
          <ul>
            {
              system[2].version.map((val, i) => {
                return <li key={i}><span className="version">Version :</span>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-3 btn_align">
          {
            system[3].assign.map((val, i) => {
              return <button className=" assign" key={i}>{val}</button>;
            })
          }


        </div>
        <div className="col-md-1 btn_align">
          {
            system[4].icon.map((val, i) => {
              return <i className="fa fa-trash delete" key={i} aria-hidden="true"></i>
            })
          }

        </div>

      </div>
    </div>);
  }
}

export class Cisco_2 extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div className="container-fluid box">
      <p>mani</p>


    </div>);
  }
}

