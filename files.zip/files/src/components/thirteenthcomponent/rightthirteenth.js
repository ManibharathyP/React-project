import React from 'react';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css' // Import css
var system = require('./data13.json');
//var system1 = require('./data3.json');
//var system2 = require('./data4.json');


export class Cisco_12 extends React.Component {
  constructor(props) {
    super(props);
    {
        
    }

  }
  changeButtonStatus(event) {
    var selectedval = event.target.value;
    var elem = document.getElementsByClassName("drop");

    for (var i = 0; i < elem.length; i++) {
      if (selectedval == elem[i].getAttribute('value')) {
        if (elem[i].style.display == "block") {
          elem[i].style.display = "none";
        }
        else {
          elem[i].style.display = "block";
          var icontop = document.getElementsByClassName("addelem");
          for (var y = 0; y < icontop.length; y++) {
            if (selectedval == icontop[y].getAttribute('value')) {
              icontop[y].classList.add("triangle");
            }
          }
        }
      }
      else {
        elem[i].style.display = "none";
      }
    }
  }
  appendcontent(event) {

    var next = event.target.parentElement.parentElement.getAttribute('value');

    var all = event.target.value;

    var p = document.getElementsByClassName("buttonval");
    var para = p.length;

    var tempElement = document.getElementsByClassName('drop')[next];
    var lastval = parseInt(tempElement.getAttribute('data-count'));

    tempElement.setAttribute('data-count', lastval - 1);
    console.log(lastval);
    for (var i = 0; i < para; i++) {
      if (parseInt(p[i].getAttribute('value')) == next) {
        var nodep = document.createElement('span');
        nodep.appendChild(document.createTextNode(all));
        nodep.classList.add('para');
        nodep.setAttribute('value', i);
        document.getElementsByClassName('buttonval')[i].appendChild(nodep);
        nodep.addEventListener("click", this.changetobutton);
        this.displayTickIcon(i);
      }
    }

    var elemList = document.getElementsByClassName('btn inner');

    for (var i = 0; i < elemList.length; i++) {
      if (elemList[i].value == all) {
        elemList[i].style.display = "none";

      }
    }
    if (tempElement.getAttribute('data-count') == 0) {
      this.hideDropArea(next);
    }

  }
  hideDropArea(index) {
    document.getElementsByClassName('drop')[index].style.display = "none";
  }
  displayTickIcon(iter) {
    var iconElemList = document.getElementsByClassName("tick");
    for (var i = 0; i < iconElemList.length; i++) {
      if (parseInt(iconElemList[i].getAttribute('value')) == iter) {
        iconElemList[i].classList.add('tickimg');
      }
    }
  }
  changetobutton(event) {
    var targetElem = event.target;
    var currentbutton = event.target.getAttribute('value');

    // button hide loop
    var dropElements = document.getElementsByClassName('drop');
    for (var dropIter = 0; dropIter < dropElements.length; dropIter++) {
      if (dropIter != parseInt(currentbutton)) {
        dropElements[dropIter].style.display = "none";
      }
    }
    var parElem = document.getElementsByClassName('para');
    var tempInnerText = event.target.innerText;
    var tempvalue = document.getElementsByClassName('drop')[currentbutton];
    var secondlast = parseInt(tempvalue.getAttribute('data-count'));
    tempvalue.setAttribute('data-count', secondlast + 1);
    if (secondlast >= 0) {
      document.getElementsByClassName('drop')[currentbutton].style.display = "block";
      var tempIterElements = document.getElementsByClassName('displaybutton');
      for (var elem = 0; elem < tempIterElements.length; elem++) {
        if (tempIterElements[elem].firstElementChild.innerText == tempInnerText) {
          tempIterElements[elem].firstElementChild.removeAttribute('style');
          targetElem.remove();
          if (parElem.length == 0) {
            document.getElementsByClassName('tick')[currentbutton].classList.remove('tickimg');

          }
        }
      }
    } else {
      var appendedList = document.getElementsByClassName('buttonval')[currentbutton]
      var iconElemList = document.getElementsByClassName("tick");
      var replace = document.getElementsByClassName("tagButtons");
      var replacelen = replace.length;
      for (var i = 0; i < replacelen; i++) {
        if (replace[i].getAttribute('style') != null && replace[i].innerText == event.target.innerText) {
          replace[i].removeAttribute('style');
          event.target.remove();
          for (var i = 0; i < iconElemList.length; i++) {
            if (parseInt(iconElemList[i].getAttribute('value')) == currentbutton && appendedList.childElementCount == 0) {
              iconElemList[i].classList.remove('tickimg');
            }
          }
        }
      }
    }
    var tickIconElemList = document.getElementsByClassName("tick");
    var counter = 0;
    if (parElem.length > 0) {
      for (var parelemiter = 0; parelemiter < parElem.length; parelemiter++) {
        if (parElem[parelemiter].getAttribute('value') == currentbutton) {
          counter++;
        }
      }
    }
    if (counter == 0) {
      tickIconElemList[currentbutton].classList.remove("tickimg");
    }
  }
  color(event) {
    var colorvalue = event.target.getAttribute('value');
    var iconcolor = document.getElementsByClassName("star");
    for (var i = 0; i < iconcolor.length; i++) {
      if (parseInt(iconcolor[i].getAttribute('value')) == colorvalue) {
        iconcolor[i].classList.toggle("yellowcolor");
      }
    }
  }
  deleterow(event) {
    var delval = parseInt(event.target.getAttribute('value'));
    var delList = [];
    if (!document.getElementsByClassName('buttonval')[delval].childElementCount == 0) {
      confirmAlert({
        //title: 'Confirm to submit',
        message: 'Are you sure to delete',
        buttons: [
          {
            label: 'Yes',
            onClick: () => {
              var deletedvalue = document.getElementsByClassName("buttonval");
              var iconElemList = document.getElementsByClassName("tick");
              for (var i = 0; i < deletedvalue.length; i++) {
                if (parseInt(deletedvalue[i].getAttribute('value')) == delval) {
                  for (var dummy = 0; dummy < deletedvalue[i].childElementCount; dummy++) {
                    delList.push(deletedvalue[i].childNodes[dummy].innerText);
                  }
                  deletedvalue[i].innerText = "";
                  deletedvalue[i].classList.remove('para');
                }
              }
              for (var i = 0; i < iconElemList.length; i++) {
                if (parseInt(iconElemList[i].getAttribute('value')) == delval) {
                  iconElemList[i].classList.remove('tickimg');
                }
              }
              var elemList = document.getElementsByClassName('drop');
              var hidebutn = document.getElementsByClassName('tagButtons');

              for (var i = 0; i < elemList.length; i++) {
                if (elemList[i].getAttribute('style') != undefined) {
                  elemList[i].style.display = "none";
                  for (var hideb = 0; hideb < hidebutn.length; hideb++) {
                    //var paragraphElements = document.getElementsByClassName('para');
                    // if (paragraphElements.length != 0) {
                    //   for (var paraIter = 0; paraIter < paragraphElements.length; paraIter++) {
                    //     if (paragraphElements[paraIter].innerText != hidebutn[hideb].innerText) {
                    //       if (hidebutn[hideb].getAttribute('style') != undefined) {
                    //         hidebutn[hideb].removeAttribute('style');
                    //       }
                    //     }
                    //   }
                    // }

                    for (var listiter = 0; listiter < delList.length; listiter++) {
                      for (var hidebtnitr = 0; hidebtnitr < hidebutn.length; hidebtnitr++) {
                        if (hidebutn[hidebtnitr].innerText == delList[listiter]) {
                          hidebutn[hidebtnitr].removeAttribute('style');
                        }
                      }
                    }
                    // if (hidebutn[hideb].getAttribute('style') != undefined) {
                    //   hidebutn[hideb].removeAttribute('style');
                    // }
                  }
                }
              }
            }
          },
          {
            label: 'No'
          }
        ]
      })
    }
  }



  render() {

    return (<div className="container-fluid box ">
      {
        system.map((val, i) => {
          return <div className="tableview" key={i}>
            <table className="table">
              <tbody>
                <tr key={i}>
                  <td><div className="testspan" value={i}><i value={i} className="fa fa-star star" aria-hidden="true" onClick={this.color.bind(this)}></i>&nbsp;{val.operating}<br></br><span className="instal">Installed Image:<span className="digit">1</span></span><span className="buttonval" value={i} ></span></div></td>
                  <td><span className="version">Version :</span>&nbsp;{val.version}</td>
                  <td>
                    <div className="assignbutton">
                      <img value={i} src="./../images/tick.png" className="tick"></img><button className="assign" value={i} key={i} onClick={this.changeButtonStatus.bind(this)}>{val.assign}</button>
                    </div>
                    <div className="row">

                      <div className="col-md-12 drop" data-count="7" value={i} >
                        {
                          system.map((val, j) => {

                            return <div className="displaybutton" data-parentattrvalue={i} key={j} value={j}><button className="btn inner tagButtons" key={j} value={val.button} onClick={this.appendcontent.bind(this)}>{val.button}</button><span className="addelem" value={j}></span></div>
                          })
                        }
                      </div>

                    </div>

                  </td>
                  <td>
                    <i className="fa fa-trash-o delete" disabled key={i} value={i} aria-hidden="true" data-tip="delete" onClick={this.deleterow.bind(this)}></i>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        })
      }


    </div>);
  }
}

// export class Cisco_2 extends React.Component {
//   constructor(props) {
//     super(props);
//     {

//     }

//   }
//   changeButtonStatus1(event) {
//     var selectedval = event.target.value;
//     var elem = document.getElementsByClassName("drop");

//     for (var i = 0; i < elem.length; i++) {
//       if (selectedval == elem[i].getAttribute('value')) {
//         if (elem[i].style.display == "block") {
//           elem[i].style.display = "none";
//         }
//         else {
//           elem[i].style.display = "block";
//           var icontop = document.getElementsByClassName("addelem");
//           for (var y = 0; y < icontop.length; y++) {
//             if (selectedval == icontop[y].getAttribute('value')) {
//               icontop[y].classList.add("triangle");
//             }
//           }
//         }
//       }
//       else {
//         elem[i].style.display = "none";
//       }
//     }
//   }
//   appendcontent1(event) {

//     var next = event.target.parentElement.parentElement.getAttribute('value');

//     var all = event.target.value;

//     var p = document.getElementsByClassName("buttonval");
//     var para = p.length;

//     var tempElement = document.getElementsByClassName('drop')[next];
//     var lastval = parseInt(tempElement.getAttribute('data-count'));

//     tempElement.setAttribute('data-count', lastval - 1);
//     //console.log(lastval);
//     for (var i = 0; i < para; i++) {
//       if (parseInt(p[i].getAttribute('value')) == next) {
//         var nodep = document.createElement('span');
//         nodep.appendChild(document.createTextNode(all));
//         nodep.classList.add('para');
//         nodep.setAttribute('value', i);
//         document.getElementsByClassName('buttonval')[i].appendChild(nodep);
//         nodep.addEventListener("click", this.changetobutton);
//         this.displayTickIcon1(i);
//       }
//     }

//     var elemList = document.getElementsByClassName('btn inner');

//     for (var i = 0; i < elemList.length; i++) {
//       if (elemList[i].value == all) {
//         elemList[i].style.display = "none";

//       }
//     }
//     if (tempElement.getAttribute('data-count') == 0) {
//       this.hideDropArea1(next);
//     }

//   }
//   hideDropArea1(index) {
//     document.getElementsByClassName('drop')[index].style.display = "none";
//   }
//   displayTickIcon1(iter) {
//     var iconElemList = document.getElementsByClassName("tick");
//     for (var i = 0; i < iconElemList.length; i++) {
//       if (parseInt(iconElemList[i].getAttribute('value')) == iter) {
//         iconElemList[i].classList.add('tickimg');
//       }
//     }
//   }
//   changetobutton1(event) {
//     var targetElem = event.target;
//     //console.log(targetElem)
//     var currentbutton = event.target.getAttribute('value');

//     // button hide loop
//     var dropElements = document.getElementsByClassName('drop');
//     for (var dropIter = 0; dropIter < dropElements.length; dropIter++) {
//       if (dropIter != parseInt(currentbutton)) {
//         dropElements[dropIter].style.display = "none";
//       }
//     }
//     var parElem = document.getElementsByClassName('para');
//     //console.log(parElem);
//     var tempInnerText = event.target.innerText;
//     var tempvalue = document.getElementsByClassName('drop')[currentbutton];
//     var secondlast = parseInt(tempvalue.getAttribute('data-count'));
//     tempvalue.setAttribute('data-count', secondlast + 1);
//     if (secondlast >= 0) {
//       document.getElementsByClassName('drop')[currentbutton].style.display = "block";
//       var tempIterElements = document.getElementsByClassName('displaybutton');
//       for (var elem = 0; elem < tempIterElements.length; elem++) {
//         if (tempIterElements[elem].firstElementChild.innerText == tempInnerText) {
//           tempIterElements[elem].firstElementChild.removeAttribute('style');
//           targetElem.remove();
//           if (parElem.length == 0) {
//             document.getElementsByClassName('tick')[currentbutton].classList.remove('tickimg');

//           }
//         }
//       }
//     } else {
//       var appendedList = document.getElementsByClassName('buttonval')[currentbutton]
//       var iconElemList = document.getElementsByClassName("tick");
//       var replace = document.getElementsByClassName("tagButtons");
//       var replacelen = replace.length;
//       for (var i = 0; i < replacelen; i++) {
//         if (replace[i].getAttribute('style') != null && replace[i].innerText == event.target.innerText) {
//           replace[i].removeAttribute('style');
//           event.target.remove();
//           for (var i = 0; i < iconElemList.length; i++) {
//             if (parseInt(iconElemList[i].getAttribute('value')) == currentbutton && appendedList.childElementCount == 0) {
//               iconElemList[i].classList.remove('tickimg');
//             }
//           }
//         }
//       }
//     }
//     var tickIconElemList = document.getElementsByClassName("tick");
//     var counter = 0;
//     if (parElem.length > 0) {
//       for (var parelemiter = 0; parelemiter < parElem.length; parelemiter++) {
//         if (parElem[parelemiter].getAttribute('value') == currentbutton) {
//           counter++;
//         }
//       }
//     }
//     if (counter == 0) {
//       tickIconElemList[currentbutton].classList.remove("tickimg");
//     }
//   }
//   color1(event) {
//     var colorvalue = event.target.getAttribute('value');
//     var iconcolor = document.getElementsByClassName("star");
//     for (var i = 0; i < iconcolor.length; i++) {
//       if (parseInt(iconcolor[i].getAttribute('value')) == colorvalue) {
//         iconcolor[i].classList.toggle("yellowcolor");
//       }
//     }
//   }
//   deleterow1(event) {
//     var delval = parseInt(event.target.getAttribute('value'));
//     var delList = [];
//     if (!document.getElementsByClassName('buttonval')[delval].childElementCount == 0) {
//       confirmAlert({
//         //title: 'Confirm to submit',
//         message: 'Are you sure to delete',
//         buttons: [
//           {
//             label: 'Yes',
//             onClick: () => {
//               var deletedvalue = document.getElementsByClassName("buttonval");
//               var iconElemList = document.getElementsByClassName("tick");
//               for (var i = 0; i < deletedvalue.length; i++) {
//                 if (parseInt(deletedvalue[i].getAttribute('value')) == delval) {
//                   for (var dummy = 0; dummy < deletedvalue[i].childElementCount; dummy++) {
//                     delList.push(deletedvalue[i].childNodes[dummy].innerText);
//                   }
//                   deletedvalue[i].innerText = "";
//                   deletedvalue[i].classList.remove('para');
//                 }
//               }
//               for (var i = 0; i < iconElemList.length; i++) {
//                 if (parseInt(iconElemList[i].getAttribute('value')) == delval) {
//                   iconElemList[i].classList.remove('tickimg');
//                 }
//               }
//               var elemList = document.getElementsByClassName('drop');
//               var hidebutn = document.getElementsByClassName('tagButtons');

//               for (var i = 0; i < elemList.length; i++) {
//                 if (elemList[i].getAttribute('style') != undefined) {
//                   elemList[i].style.display = "none";
//                   for (var hideb = 0; hideb < hidebutn.length; hideb++) {
//                     for (var listiter = 0; listiter < delList.length; listiter++) {
//                       for (var hidebtnitr = 0; hidebtnitr < hidebutn.length; hidebtnitr++) {
//                         if (hidebutn[hidebtnitr].innerText == delList[listiter]) {
//                           hidebutn[hidebtnitr].removeAttribute('style');
//                         }
//                       }
//                     }
//                   }
//                 }
//               }
//             }
//           },
//           {
//             label: 'No'
//           }
//         ]
//       })
//     }
//   }



//   render() {

//     return (<div className="container-fluid box ">
//       {
//         system1.map((val, i) => {
//           return <div className="tableview" key={i}>
//             <table className="table">
//               <tbody>
//                 <tr key={i}>
//                   <td><div className="testspan" value={i}><i value={i} className="fa fa-star star" aria-hidden="true" onClick={this.color1.bind(this)}></i>&nbsp;{val.operating}<br></br><span className="instal">Installed Image:<span className="digit">1</span></span><span className="buttonval" value={i} ></span></div></td>
//                   <td><span className="version">Version :</span>&nbsp;{val.version}</td>
//                   <td>
//                     <div className="assignbutton">
//                       <img value={i} src="./../images/tick.png" className="tick"></img><button className="assign" value={i} key={i} onClick={this.changeButtonStatus1.bind(this)}>{val.assign}</button>
//                     </div>
//                     <div className="row">

//                       <div className="col-md-12 drop" data-count="7" value={i} >
//                         {
//                           system1.map((val, j) => {

//                             return <div className="displaybutton" data-parentattrvalue={i} key={j} value={j}><button className="btn inner tagButtons" key={j} value={val.button} onClick={this.appendcontent1.bind(this)}>{val.button}</button><span className="addelem" value={j}></span></div>
//                           })
//                         }
//                       </div>

//                     </div>

//                   </td>
//                   <td>
//                     <i className="fa fa-trash-o delete" disabled key={i} value={i} aria-hidden="true" data-tip="delete" onClick={this.deleterow1.bind(this)}></i>
//                   </td>
//                 </tr>
//               </tbody>
//             </table>
//           </div>
//         })
//       }


//     </div>);
//   }
// }

// export class Cisco_3 extends React.Component {
//   constructor(props) {
//     super(props);
//     {

//     }

//   }
//   changeButtonStatus2(event) {
//     var selectedval = event.target.value;
//     var elem = document.getElementsByClassName("drop");

//     for (var i = 0; i < elem.length; i++) {
//       if (selectedval == elem[i].getAttribute('value')) {
//         if (elem[i].style.display == "block") {
//           elem[i].style.display = "none";
//         }
//         else {
//           elem[i].style.display = "block";
//           var icontop = document.getElementsByClassName("addelem");
//           for (var y = 0; y < icontop.length; y++) {
//             if (selectedval == icontop[y].getAttribute('value')) {
//               icontop[y].classList.add("triangle");
//             }
//           }
//         }
//       }
//       else {
//         elem[i].style.display = "none";
//       }
//     }
//   }
//   appendcontent2(event) {

//     var next = event.target.parentElement.parentElement.getAttribute('value');

//     var all = event.target.value;

//     var p = document.getElementsByClassName("buttonval");
//     var para = p.length;

//     var tempElement = document.getElementsByClassName('drop')[next];
//     var lastval = parseInt(tempElement.getAttribute('data-count'));

//     tempElement.setAttribute('data-count', lastval - 1);
//     console.log(lastval);
//     for (var i = 0; i < para; i++) {
//       if (parseInt(p[i].getAttribute('value')) == next) {
//         var nodep = document.createElement('span');
//         nodep.appendChild(document.createTextNode(all));
//         nodep.classList.add('para');
//         nodep.setAttribute('value', i);
//         document.getElementsByClassName('buttonval')[i].appendChild(nodep);
//         nodep.addEventListener("click", this.changetobutton);
//         this.displayTickIcon2(i);
//       }
//     }

//     var elemList = document.getElementsByClassName('btn inner');

//     for (var i = 0; i < elemList.length; i++) {
//       if (elemList[i].value == all) {
//         elemList[i].style.display = "none";

//       }
//     }
//     if (tempElement.getAttribute('data-count') == 0) {
//       this.hideDropArea2(next);
//     }

//   }
//   hideDropArea2(index) {
//     document.getElementsByClassName('drop')[index].style.display = "none";
//   }
//   displayTickIcon2(iter) {
//     var iconElemList = document.getElementsByClassName("tick");
//     for (var i = 0; i < iconElemList.length; i++) {
//       if (parseInt(iconElemList[i].getAttribute('value')) == iter) {
//         iconElemList[i].classList.add('tickimg');
//       }
//     }
//   }
//   changetobutton2(event) {
//     var targetElem = event.target;
//     var currentbutton = event.target.getAttribute('value');

//     // button hide loop
//     var dropElements = document.getElementsByClassName('drop');
//     for (var dropIter = 0; dropIter < dropElements.length; dropIter++) {
//       if (dropIter != parseInt(currentbutton)) {
//         dropElements[dropIter].style.display = "none";
//       }
//     }
//     var parElem = document.getElementsByClassName('para');
//     var tempInnerText = event.target.innerText;
//     var tempvalue = document.getElementsByClassName('drop')[currentbutton];
//     var secondlast = parseInt(tempvalue.getAttribute('data-count'));
//     tempvalue.setAttribute('data-count', secondlast + 1);
//     if (secondlast >= 0) {
//       document.getElementsByClassName('drop')[currentbutton].style.display = "block";
//       var tempIterElements = document.getElementsByClassName('displaybutton');
//       for (var elem = 0; elem < tempIterElements.length; elem++) {
//         if (tempIterElements[elem].firstElementChild.innerText == tempInnerText) {
//           tempIterElements[elem].firstElementChild.removeAttribute('style');
//           targetElem.remove();
//           if (parElem.length == 0) {
//             document.getElementsByClassName('tick')[currentbutton].classList.remove('tickimg');

//           }
//         }
//       }
//     } else {
//       var appendedList = document.getElementsByClassName('buttonval')[currentbutton]
//       var iconElemList = document.getElementsByClassName("tick");
//       var replace = document.getElementsByClassName("tagButtons");
//       var replacelen = replace.length;
//       for (var i = 0; i < replacelen; i++) {
//         if (replace[i].getAttribute('style') != null && replace[i].innerText == event.target.innerText) {
//           replace[i].removeAttribute('style');
//           event.target.remove();
//           for (var i = 0; i < iconElemList.length; i++) {
//             if (parseInt(iconElemList[i].getAttribute('value')) == currentbutton && appendedList.childElementCount == 0) {
//               iconElemList[i].classList.remove('tickimg');
//             }
//           }
//         }
//       }
//     }
//     var tickIconElemList = document.getElementsByClassName("tick");
//     var counter = 0;
//     if (parElem.length > 0) {
//       for (var parelemiter = 0; parelemiter < parElem.length; parelemiter++) {
//         if (parElem[parelemiter].getAttribute('value') == currentbutton) {
//           counter++;
//         }
//       }
//     }
//     if (counter == 0) {
//       tickIconElemList[currentbutton].classList.remove("tickimg");
//     }
//   }
//   color2(event) {
//     var colorvalue = event.target.getAttribute('value');
//     var iconcolor = document.getElementsByClassName("star");
//     for (var i = 0; i < iconcolor.length; i++) {
//       if (parseInt(iconcolor[i].getAttribute('value')) == colorvalue) {
//         iconcolor[i].classList.toggle("yellowcolor");
//       }
//     }
//   }
//   deleterow2(event) {
//     var delval = parseInt(event.target.getAttribute('value'));
//     var delList = [];
//     if (!document.getElementsByClassName('buttonval')[delval].childElementCount == 0) {
//       confirmAlert({
//         //title: 'Confirm to submit',
//         message: 'Are you sure to delete',
//         buttons: [
//           {
//             label: 'Yes',
//             onClick: () => {
//               var deletedvalue = document.getElementsByClassName("buttonval");
//               var iconElemList = document.getElementsByClassName("tick");
//               for (var i = 0; i < deletedvalue.length; i++) {
//                 if (parseInt(deletedvalue[i].getAttribute('value')) == delval) {
//                   for (var dummy = 0; dummy < deletedvalue[i].childElementCount; dummy++) {
//                     delList.push(deletedvalue[i].childNodes[dummy].innerText);
//                   }
//                   deletedvalue[i].innerText = "";
//                   deletedvalue[i].classList.remove('para');
//                 }
//               }
//               for (var i = 0; i < iconElemList.length; i++) {
//                 if (parseInt(iconElemList[i].getAttribute('value')) == delval) {
//                   iconElemList[i].classList.remove('tickimg');
//                 }
//               }
//               var elemList = document.getElementsByClassName('drop');
//               var hidebutn = document.getElementsByClassName('tagButtons');

//               for (var i = 0; i < elemList.length; i++) {
//                 if (elemList[i].getAttribute('style') != undefined) {
//                   elemList[i].style.display = "none";
//                   for (var hideb = 0; hideb < hidebutn.length; hideb++) {
//                     //var paragraphElements = document.getElementsByClassName('para');
//                     // if (paragraphElements.length != 0) {
//                     //   for (var paraIter = 0; paraIter < paragraphElements.length; paraIter++) {
//                     //     if (paragraphElements[paraIter].innerText != hidebutn[hideb].innerText) {
//                     //       if (hidebutn[hideb].getAttribute('style') != undefined) {
//                     //         hidebutn[hideb].removeAttribute('style');
//                     //       }
//                     //     }
//                     //   }
//                     // }

//                     for (var listiter = 0; listiter < delList.length; listiter++) {
//                       for (var hidebtnitr = 0; hidebtnitr < hidebutn.length; hidebtnitr++) {
//                         if (hidebutn[hidebtnitr].innerText == delList[listiter]) {
//                           hidebutn[hidebtnitr].removeAttribute('style');
//                         }
//                       }
//                     }
//                     // if (hidebutn[hideb].getAttribute('style') != undefined) {
//                     //   hidebutn[hideb].removeAttribute('style');
//                     // }
//                   }
//                 }
//               }
//             }
//           },
//           {
//             label: 'No'
//           }
//         ]
//       })
//     }
//   }



//   render() {

//     return (<div className="container-fluid box ">
//       {
//         system2.map((val, i) => {
//           return <div className="tableview" key={i}>
//             <table className="table">
//               <tbody>
//                 <tr key={i}>
//                   <td><div className="testspan" value={i}><i value={i} className="fa fa-star star" aria-hidden="true" onClick={this.color2.bind(this)}></i>&nbsp;{val.operating}<br></br><span className="instal">Installed Image:<span className="digit">1</span></span><span className="buttonval" value={i} ></span></div></td>
//                   <td><span className="version">Version :</span>&nbsp;{val.version}</td>
//                   <td>
//                     <div className="assignbutton">
//                       <img value={i} src="./../images/tick.png" className="tick"></img><button className="assign" value={i} key={i} onClick={this.changeButtonStatus2.bind(this)}>{val.assign}</button>
//                     </div>
//                     <div className="row">

//                       <div className="col-md-12 drop" data-count="7" value={i} >
//                         {
//                           system2.map((val, j) => {

//                             return <div className="displaybutton" data-parentattrvalue={i} key={j} value={j}><button className="btn inner tagButtons" key={j} value={val.button} onClick={this.appendcontent2.bind(this)}>{val.button}</button><span className="addelem" value={j}></span></div>
//                           })
//                         }
//                       </div>

//                     </div>

//                   </td>
//                   <td>
//                     <i className="fa fa-trash-o delete" disabled key={i} value={i} aria-hidden="true" data-tip="delete" onClick={this.deleterow2.bind(this)}></i>
//                   </td>
//                 </tr>
//               </tbody>
//             </table>
//           </div>
//         })
//       }


//     </div>);
//   }
// }
