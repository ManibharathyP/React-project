import React from 'react';
import { Cisco_1 } from '../anothercomponent/right';
import { Cisco_2 } from './../thirdcomponent/rightthird';
import { Cisco_3 } from './../fourthcomponent/rightfourth';
import { Cisco_4 } from './../fifthcomponent/rightfifth';
import { Cisco_5 } from './../sixthcomponent/rightsixth';
import { Cisco_6 } from './../seventhcomponent/rightseventh';
import { Cisco_7 } from './../eighthcomponent/righteighth';
import { Cisco_8 } from './../ninethcomponent/rightnineth';
import { Cisco_9 } from './../tenthcomponent/righttenth';
import { Cisco_10 } from './../eleventhcomponent/righteleventh';
import { Cisco_11 } from './../twelvethcomponent/righttweleve';
import { Cisco_12 } from './../thirteenthcomponent/rightthirteenth';
import ReactDOM from 'react-dom';
import ReactTooltip from 'react-tooltip'
import { Link } from 'react-router-dom';
var jsonvalues = require('./data.json');

class anothercomponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      "active": "",
      "elem": ""
    }

  }

  componentDidMount() {
    var sidemenu = document.getElementsByClassName('sidemenu');
    sidemenu[0].firstChild.classList.add('selected');
  }

  loadcomponent(evt) {
    var sidemenu = document.getElementsByClassName('sidemenu');
    sidemenu[0].firstChild.classList.remove('selected');
    this.setState({
      "elem": evt.target.value,
      "active": "selected"
    })


    // alert(evt.target.value);

    switch (evt.target.value) {
      case 0: ReactDOM.render(<Cisco_1 />, document.getElementById('comp'));
        break;
      case 1: ReactDOM.render(<Cisco_2 />, document.getElementById('comp'));
        break
      case 2: ReactDOM.render(<Cisco_3 />, document.getElementById('comp'));
        break
      case 3: ReactDOM.render(<Cisco_4 />, document.getElementById('comp'));
        break
      case 4: ReactDOM.render(<Cisco_5 />, document.getElementById('comp'));
        break
      case 5: ReactDOM.render(<Cisco_6 />, document.getElementById('comp'));
        break
      case 6: ReactDOM.render(<Cisco_7 />, document.getElementById('comp'));
        break
      case 7: ReactDOM.render(<Cisco_8 />, document.getElementById('comp'));
        break
      case 8: ReactDOM.render(<Cisco_9 />, document.getElementById('comp'));
        break
      case 9: ReactDOM.render(<Cisco_10 />, document.getElementById('comp'));
        break
        case 10: ReactDOM.render(<Cisco_11 />, document.getElementById('comp'));
        break
        case 11: ReactDOM.render(<Cisco_12 />, document.getElementById('comp'));
        break
      default: return null;
    }
  }

  render() {
    return (<div className="another">
      <ReactTooltip />
      <div className="row">
        <div className="col-md-4 ">
          <img className="insidelogo" src="./../images/mainlogo.png"></img>
          <h4 className="text">DNA center</h4>
        </div>
        <div className="col-md-4 ">
          <p className="Loginname">Welcome {this.props.match.params.username.toUpperCase()}</p>
        </div>
        <div className="col-md-4">

          <i className="fa fa-cog setting fa-2x" aria-hidden="true" data-tip="Setting"></i>
          <i className="fa fa-bars thead fa-2x" aria-hidden="true" data-tip="Details"></i>
          <Link to="/">
            <i className="fa fa-sign-out setting fa-2x" aria-hidden="true" ></i>
          </Link>
        </div>
      </div>
      <hr></hr>
      <div className="row">
        <div className="col-md-6 ">
          <h4 className="text">Physical</h4>
          <p className="text">|</p>
          <h4 className="text blue">Virtual</h4>
        </div>
        <div className="col-md-6">

          <i className="fa fa-exclamation-circle icon thead fa-2x" aria-hidden="true" data-tip="Help"></i>
          <p className="pipe">|</p>
          <i className="fa fa-list setting icon fa-2x" aria-hidden="true" data-tip="List"></i>
          <p className="pipe">|</p>
          <i className="fa fa-upload thead icon fa-2x" aria-hidden="true" data-tip="Upload"></i>
          <p className="pipe">|</p>
          <i className="fa fa-download setting icon fa-2x" aria-hidden="true" data-tip="Download"></i>

        </div>
      </div>
      <div className="row">
        <div className="col-md-3 bgcolor">
          <h4 className="headtext">Select Device Family</h4>

          <ul className="sidemenu">
            {
              jsonvalues[0].name.map((val, i) => {
                return <li key={i} value={i} className={`staticborder ${(this.state.active === "selected" && this.state.elem === i) ? 'selected' : ''}`} onClick={this.loadcomponent.bind(this)}>{val}</li>;
              })
            }
          </ul>
        </div>
        <div className="col-md-9 click" id="comp">
          <Cisco_1 />

        </div>
      </div>
    </div>);
  }
}
export default anothercomponent



