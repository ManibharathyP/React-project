import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';
import { Route, Switch, BrowserRouter as Router } from 'react-router-dom';
import Login from './components/loginComponent/loginComponent';
import anothercomponent from './components/anothercomponent/anothercomponent'; 

const routing = (
    <Router>
      <Switch>
        <Route  exact path="/" component={Login} />
        <Route  path="/dashboard/:username" component={anothercomponent} />
      </Switch>
    </Router>
  )
  ReactDOM.render(routing, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();






